# coding: utf-8
import pilasengine

def juegaRama(pilas):
    jugador=Jugador(pilas)
    print ("juegaRama")
    print(jugador.nombre);
    jugador.nombre="rama"
    print ("Rama jugadorlin42")
#    jugador.formatear()

def juegaStefan(pilas):
    print ("juegaStefan")
    jugador = Jugador(pilas)
    jugador.nombre = "stefan"
#    jugador.formatear()

def juegaFede(pilas):
    print ("juegaFede")
    jugador = Jugador(pilas)
    jugador.nombre = "fede"
#    jugador.formatear()

def juegaNacho(pilas):
    print ("juegaNacho")
    jugador = Jugador(pilas)
    jugador.nombre = "nacho"
#   jugador.formatear()
###copiado de selecciona_jugador


class Jugador(pilasengine.actores.Actor):
    nombre = "nombrejugador"

    def iniciar(self):
        print( "JUgador.iniciar")

    #def formatear(self):
    #    self.imagen = "imagenes/" + self.nombre + ".jpg"
    #    self.escala = 0.1
    #    self.decir("Hola, me llamo " + self.nombre)

def test():
    print( "hola test")

def selecciona_jugador(pilas,texto_menu,menuppal):
    texto_menu.eliminar()
    menuppal.borrar()
    texto_actores = pilas.actores.Texto("Elegi tu jugador")
    print("band2")
    texto_actores.y = 200
    texto_actores.color = pilas.colores.Color(255, 0, 0, 0)
    texto_actores.escala = 2
    menuJugadores(pilas)
    print ("En selecciona_jugador")

def menuJugadores(pilas):
    menujugadores = pilas.actores.Menu(
        [
            ('rama', juegaRama(pilas)),
            ('stefan', juegaStefan(pilas)),
            ('fede', juegaFede(pilas)),
            ('nacho', juegaNacho(pilas))
        ])


#### copiado de selecciona_jugador